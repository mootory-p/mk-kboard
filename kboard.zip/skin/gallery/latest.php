<div id="kboard-thumbnail-latest">


	
		<?php while($content = $list->hasNext()):?>
		<div class="post-image-card">
			<div class="latest-title" >
	
					<a href="<?php echo $url->getDocumentURLWithUID($content->uid)?>">
						<div class="kboard-thumbnail-cut-strings">
						  <?php echo $content->title?>
							<?php if($content->isNew()):?><span class="kboard-thumbnail-new-notify">N</span><?php endif?>
							<?php if($content->secret):?><img src="<?php echo $skin_path?>/images/icon-lock.png" alt="<?php echo __('Secret', 'kboard')?>"><?php endif?>
							
							<span class="kboard-comments-count"><?php echo $content->getCommentsCount()?></span>
						</div>
					</a>
				
				<p class="kboard-latest-date"><?php echo $content->getDate()?></p>
			</div>
			
			<div class="latest-thumnail">
				<a href="<?php echo $url->set('uid', $content->uid)->set('mod', 'document')->toStringWithPath($board_url)?>">
					<?php if($content->getThumbnail(400, 300)):?><img src="<?php echo $content->getThumbnail(400, 300)?>" alt=""><?php else:?><i class="icon-picture"></i><?php endif?>
				</a>
			</div>
		</div>
		<?php endwhile?>
	

</div>