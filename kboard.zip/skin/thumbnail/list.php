<div id="kboard-thumbnail-list">
	
	<!-- 게시판 정보 시작 -->
	
	<!-- 게시판 정보 끝 -->
	
	<!-- 카테고리 시작 -->
	<?php
	if($board->use_category == 'yes'){
		if($board->isTreeCategoryActive()){
			$category_type = 'tree-select';
		}
		else{
			$category_type = 'default';
		}
		$category_type = apply_filters('kboard_skin_category_type', $category_type, $board, $boardBuilder);
		echo $skin->load($board->skin, "list-category-{$category_type}.php", $vars);
	}
	?>
	<!-- 카테고리 끝 -->
	
	
	<!-- 리스트 시작 -->
	<div class="kboard-list">
		
		<ul class="gallery-kb">
		
				<?php while($content = $list->hasNextNotice()):?>
				<li class="<?php echo esc_attr($content->getClass())?>">
					
					<div class="kboard-list-thumbnail">
						<a href="<?php echo esc_url($url->getDocumentURLWithUID($content->uid))?>">
						<?php if($content->getThumbnail(120, 90)):?><img src="<?php echo $content->getThumbnail(120, 90)?>" alt="<?php echo esc_attr($content->title)?>"><?php else:?><i class="icon-picture"></i><?php endif?>
						</a>
					</div>
					<div class="kboard-list-title">
						<a href="<?php echo esc_url($url->getDocumentURLWithUID($content->uid))?>">
							<div class="kboard-thumbnail-cut-strings">
								<?php if($content->getThumbnail(96, 70)):?>
								<div class="kboard-mobile-contents">
									<img src="<?php echo $content->getThumbnail(96, 70)?>" alt="<?php echo esc_attr($content->title)?>" class="contents-thumbnail">
								</div>
								<?php endif?>
								<?php if($content->isNew()):?><span class="kboard-thumbnail-new-notify">New</span><?php endif?>
								<?php if($content->secret):?><img src="<?php echo $skin_path?>/images/icon-lock.png" alt="<?php echo __('Secret', 'kboard')?>"><?php endif?>
								<?php echo $content->title?>
								<span class="kboard-comments-count"><?php echo $content->getCommentsCount()?></span>
							</div>
						</a>
					</div>
					
				</li>
				<?php endwhile?>
				<?php while($content = $list->hasNextPopular()):?>
				<li class="<?php echo esc_attr($content->getClass())?>">
					
					<div class="kboard-list-thumbnail">
						<a href="<?php echo esc_url($url->getDocumentURLWithUID($content->uid))?>">
						<?php if($content->getThumbnail(120, 90)):?><img src="<?php echo $content->getThumbnail(120, 90)?>" alt="<?php echo esc_attr($content->title)?>"><?php else:?><i class="icon-picture"></i><?php endif?>
						</a>
					</div>
					<div class="kboard-list-title">
						<a href="<?php echo esc_url($url->getDocumentURLWithUID($content->uid))?>">
							<div class="kboard-thumbnail-cut-strings">
								<?php if($content->getThumbnail(96, 70)):?>
								<div class="kboard-mobile-contents">
									<img src="<?php echo $content->getThumbnail(96, 70)?>" alt="<?php echo esc_attr($content->title)?>" class="contents-thumbnail">
								</div>
								<?php endif?>
								<?php if($content->isNew()):?><span class="kboard-thumbnail-new-notify">New</span><?php endif?>
								<?php if($content->secret):?><img src="<?php echo $skin_path?>/images/icon-lock.png" alt="<?php echo __('Secret', 'kboard')?>"><?php endif?>
								<?php echo $content->title?>
								<span class="kboard-comments-count"><?php echo $content->getCommentsCount()?></span>
							</div>
						</a>
					</div>
					
					
				</li>
				<?php $boardBuilder->builderReply($content->uid)?>
				<?php endwhile?>
				<?php while($content = $list->hasNext()):?>

				<li class="<?php echo esc_attr($content->getClass())?>">
					<?php if($content->getThumbnail(400, 300)):?>
					<div class="kboard-list-thumbnail onlypc">
						<a href="<?php echo esc_url($url->getDocumentURLWithUID($content->uid))?>">
							
								<img src="<?php echo $content->getThumbnail(400, 300)?>" alt="<?php echo esc_attr($content->title)?>">
							
						</a>
					</div>
					<?php else:?>
						<i class="icon-picture"></i>
					<?php endif?>

					<div class="kboard-list-title webzine ">
						<a href="<?php echo esc_url($url->getDocumentURLWithUID($content->uid))?>">
							<div class="kboard-thumbnail-cut-strings kb-title-strings">
								<?php if($content->getThumbnail(400, 300)):?>
								<div class="kboard-mobile-contents">
									<img src="<?php echo $content->getThumbnail(400, 300)?>" alt="<?php echo esc_attr($content->title)?>" class="contents-thumbnail">
								</div>
								<?php endif?>
								<?php echo $content->title?>
								<span class="kboard-comments-count"><?php echo $content->getCommentsCount()?></span>
								<?php if($content->isNew()):?><span class="kboard-thumbnail-new-notify">N</span><?php endif?>
								<?php if($content->secret):?><img src="<?php echo $skin_path?>/images/icon-lock.png" alt="<?php echo __('Secret', 'kboard')?>"><?php endif?>
								
							</div>
						</a>
					</div>
					<p class="sub-text">
								<?php
									$content->content = str_replace('[', '&#91;', $content->getContent());
									$content->content = str_replace(']', '&#93;', $content->getContent());
									echo wp_trim_words(strip_tags($content->content), 25, '...');
									?>
								</p>

				
				</li>

				<?php $boardBuilder->builderReply($content->uid)?>
				<?php endwhile?>

		</ul>
		
	</div>
	<!-- 리스트 끝 -->
	
	<div class="kb-bottom">
		<!-- 페이징 시작 -->
	<div class="kb-page" >
		<ul class="kboard-pagination-pages">
			<?php echo kboard_pagination($list->page, $list->total, $list->rpp)?>
		</ul>
	</div>
	<!-- 페이징 끝 -->

	<?php if($board->isWriter()):?>
	<!-- 버튼 시작 -->
	<div class="kb-control">
		<a href="<?php echo esc_url($url->getContentEditor())?>" class="kboard-thumbnail-button-small"><?php echo __('New', 'kboard')?></a>
	</div>
	<!-- 버튼 끝 -->
	<?php endif?>
	</div>
	
	
	<!-- 검색폼 시작 -->
	<div class="kboard-search" style="display:none">
		<form id="kboard-search-form-<?php echo $board->id?>" method="get" action="<?php echo esc_url($url->toString())?>">
			<?php echo $url->set('pageid', '1')->set('target', '')->set('keyword', '')->set('mod', 'list')->toInput()?>
			
			<select name="target">
				<option value=""><?php echo __('All', 'kboard')?></option>
				<option value="title"<?php if(kboard_target() == 'title'):?> selected<?php endif?>><?php echo __('Title', 'kboard')?></option>
				<option value="content"<?php if(kboard_target() == 'content'):?> selected<?php endif?>><?php echo __('Content', 'kboard')?></option>
				<option value="member_display"<?php if(kboard_target() == 'member_display'):?> selected<?php endif?>><?php echo __('Author', 'kboard')?></option>
			</select>
			<input type="text" name="keyword" value="<?php echo esc_attr(kboard_keyword())?>">
			<button type="submit" class="kboard-thumbnail-button-small"><?php echo __('Search', 'kboard')?></button>
		</form>
	</div>
	<!-- 검색폼 끝 -->
	
	
	
	
</div>