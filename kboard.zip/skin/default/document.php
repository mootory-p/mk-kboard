<div id="kboard-document">
	<div id="kboard-default-document">
		<div class="kboard-document-wrap kb-default-wrap" itemscope itemtype="http://schema.org/Article">
			
			<div class="right kbdocu">
				<?php if($content->category1):?>
				<div class="detail-attr detail-category1">
					<div class="detail-name"><?php echo esc_html($content->category1)?></div>
				</div>
				<?php endif?>
				<?php if($content->category2):?>
				<div class="detail-attr detail-category2">
					<div class="detail-name"><?php echo esc_html($content->category2)?></div>
				</div>
				<?php endif?>
				<?php if($content->category3):?>
				<div class="detail-attr detail-category3">
					<div class="detail-name"><?php echo esc_html($content->category3)?></div>
				</div>
				<?php endif?>
				<?php if($content->category4):?>
				<div class="detail-attr detail-category4">
					<div class="detail-name"><?php echo esc_html($content->category4)?></div>
				</div>
				<?php endif?>
				<?php if($content->category5):?>
				<div class="detail-attr detail-category5">
					<div class="detail-name"><?php echo esc_html($content->category5)?></div>
				</div>
				<?php endif?>
				<?php if($content->option->tree_category_1):?>
				<?php for($i=1; $i<=$content->getTreeCategoryDepth(); $i++):?>
				<div class="detail-attr detail-tree-category-<?php echo $i?>">
					<div class="detail-name"><?php echo esc_html($content->option->{'tree_category_'.$i})?></div>
				</div>
				<?php endfor?>
				<?php endif?>
				<div class="detail-attr detail-writer">
					<div class="detail-value"><?php echo $content->getUserDisplay()?></div>
				</div>
				<div class="detail-attr detail-date">
					<div class="detail-value"><?php echo date('Y-m-d H:i', strtotime($content->date))?> <span class="detail-value" style="color:#fff; margin-right:5px"><?php echo $content->view?></span></div>
				</div>
				
			</div>
			<div class="kboard-detail kb-detail">

			<div class="kboard-title" itemprop="name">
				<h1><?php echo $content->title?></h1>
			</div>
			
				
			</div>
			
			<div class="kboard-content" itemprop="description">
				<div class="content-view">
					<?php echo $content->getDocumentOptionsHTML()?>
					<?php echo $content->content?>
				</div>
			</div>
			
			<?php if($content->isAttached()):?>
			<div class="kboard-attach">
				<?php foreach($content->getAttachmentList() as $key=>$attach):?>
				<button type="button" class="kboard-button-action kboard-button-download" onclick="window.location.href='<?php echo $url->getDownloadURLWithAttach($content->uid, $key)?>'" title="<?php echo sprintf(__('Download %s', 'kboard'), $attach[1])?>"><?php echo $attach[1]?></button>
				<?php endforeach?>
			</div>
			<?php endif?>
		</div>
		
		<?php if($content->visibleComments()):?>
		<div class="kboard-comments-area"><?php echo $board->buildComment($content->uid)?></div>
		<?php endif?>
		
		
		<button type="button" class="kboard-button-action kboard-button-print seconbtn" onclick="kboard_document_print('<?php echo $url->getDocumentPrint($content->uid)?>')" title="<?php echo __('Print', 'kboard')?>"><?php echo __('Print', 'kboard')?></button>

		<div class="kboard-control kb-control kb-view">
			<div class="left">

			<?php if($content->isEditor() || $board->permission_write=='all'):?>
				<a href="<?php echo esc_url($url->getContentEditor($content->uid))?>" class="kboard-thumbnail-button-small seconbtn"><?php echo __('Edit', 'kboard')?></a>
				<a href="<?php echo esc_url($url->getContentRemove($content->uid))?>" class="kboard-thumbnail-button-small seconbtn" onclick="return confirm('<?php echo __('Are you sure you want to delete?', 'kboard')?>');"><?php echo __('Delete', 'kboard')?></a>
			<?php endif?>
			</div>
			<div class="right">
			
			<?php if($board->isReply() && !$content->notice):?><a href="<?php echo $url->set('parent_uid', $content->uid)->set('mod', 'editor')->toString()?>" class="kboard-thumbnail-button-small seconbtn"><?php echo __('Reply', 'kboard')?></a><?php endif?>
				<a href="<?php echo esc_url($url->getBoardList())?>" class="kboard-thumbnail-button-small"><?php echo __('List', 'kboard')?></a>
			</div>

			
		</div>
		
		
	</div>
</div>